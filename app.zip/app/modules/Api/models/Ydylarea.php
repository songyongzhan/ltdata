<?php
/**
 * Created by PhpStorm.
 * User: songyongzhan
 * Date: 2019/1/21
 * Time: 22:45
 * Email: 574482856@qq.com
 *
 * 一带一路 模型
 */
defined('APP_PATH') OR exit('No direct script access allowed');

class YdylareaModel extends BaseModel {

}