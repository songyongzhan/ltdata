<?php
/**
 * Created by PhpStorm.
 * User: songyongzhan
 * Date: 2018/12/28
 * Time: 11:40
 * Email: 574482856@qq.com
 *
 * 出口关区 模型
 */
defined('APP_PATH') OR exit('No direct script access allowed');

class CiqModel extends BaseModel {

}