<?php
/**
 * Created by PhpStorm.
 * User: songyongzhan
 * Date: 2018/12/28
 * Time: 11:40
 * Email: 574482856@qq.com
 *
 * 贸易方式 模型
 */
defined('APP_PATH') OR exit('No direct script access allowed');

class TradeModel extends BaseModel {

}