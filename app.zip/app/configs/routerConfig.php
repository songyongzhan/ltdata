<?php
/**
 * Created by PhpStorm.
 * User: songyongzhan
 * Date: 2018/10/19
 * Time: 11:42
 * Email: 574482856@qq.com
 */

/**
 * 路由配置放在这里
 *
 */

return [

  'router'=>'bbb'

];