<?php
/**
 * Created by PhpStorm.
 * User: songyongzhan
 * Date: 2018/12/29
 * Time: 11:40
 * Email: 574482856@qq.com
 *
 * 权限管理 模型
 */
defined('APP_PATH') OR exit('No direct script access allowed');

class Role_accessModel extends BaseModel {

  /**
   * 更新用户角色
   * @param $manage_id
   * @param $role_ids
   * @return array|bool
   * @throws InvalideException
   */
  public function updateManageRole($manage_id, $role_ids) {
    $this->startTransaction();

    $delCount = $this->delete([getWhereCondition('manage_id', $manage_id)], Tools_Config::getConfig('db.mysql.prefix') . 'manage_role');


    if (!$delCount)
      return $this->rollback();

    $data = [];
    foreach ($role_ids as $val) {
      $data[] = $this->autoaddtime([
        'manage_id' => $manage_id,
        'role_id' => $val,
        'status' => 1
      ]);
    }
    $result = $this->inserMulti($data, Tools_Config::getConfig('db.mysql.prefix') . 'manage_role');
    if (!$result)
      return $this->rollback();

    $this->commit();

    return ['delCount' => $delCount, 'insert' => $result];
  }


  /**
   * 更新分组中的权限
   * @param $role_id
   * @param $role_ids
   */
  public function updateRoleAccess($role_id, $menu_ids) {

    $this->startTransaction();

    $delCount = $this->delete([getWhereCondition('role_id', $role_id)]);

    if (!$delCount)
      return $this->rollback();

    $data = [];
    foreach ($menu_ids as $val) {
      $data[] = $this->autoaddtime([
        'menu_id' => $val,
        'role_id' => $role_id,
        'status' => 1
      ]);
    }
    $result = $this->inserMulti($data);
    if (!$result)
      return $this->rollback();

    $this->commit();

    return ['delCount' => $delCount, 'insert' => $result];
  }


}