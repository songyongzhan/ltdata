<?php return array (
  'rules' => 
  array (
  ),
  'params' => 
  array (
  ),
  'file' => '/usr/local/nginx/html/ltdata/app/core/BaseModel.php',
);