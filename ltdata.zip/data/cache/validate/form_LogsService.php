<?php return array (
  'rules' => 
  array (
    'getOne' => 
    array (
      'id' => 'required|numeric',
    ),
  ),
  'params' => 
  array (
    'getOne' => 
    array (
      0 => 'id',
      'field' => '*',
    ),
  ),
  'msg' => 
  array (
    'getOne' => 
    array (
      'id.required|numeric' => 'id',
    ),
  ),
  'file' => '/usr/local/nginx/html/ltdata/app/modules/Api/services/Logs.php',
);